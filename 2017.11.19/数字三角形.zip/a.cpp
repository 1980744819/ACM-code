#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<string>
#include<vector>
#include<stack>
#include<set>
#include<map>
#include<queue>
#include<algorithm>
#define ll long long
using namespace std;
const int maxn=10000;
int main(){
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	int dp[105][105];
	int num;
	int triangle[105][105];
	while(~scanf("%d",&num)){
		for(int i=1;i<=num;i++){
			for(int j=1;j<=i;j++){
				scanf("%d",&triangle[i][j]);
				//printf("%d ",triangle[i][j]);
			}
			//printf("\n");
		}
		for(int i=num;i>=1;i--){
			for(int j=1;j<=i;j++){
				dp[i][j]=max(dp[i+1][j],dp[i+1][j+1])+triangle[i][j];
			}
		}
		printf("%d\n",dp[1][1]);
	}
    return 0;
}
