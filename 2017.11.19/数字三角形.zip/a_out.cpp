#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<string>
#include<vector>
#include<stack>
#include<set>
#include<map>
#include<queue>
#include<algorithm>
#define ll long long
using namespace std;
const int maxn=10000;
int main(){
	freopen("a.in","w",stdout);
	for(int k=2;k<=100;k++){
		printf("%d\n",k);
		for(int i=1;i<=k;i++){
			for(int j=1;j<=i;j++){
				printf("%d ",rand()%100);
			}
			printf("\n");
		}
		printf("\n");
	}
    return 0;
}
