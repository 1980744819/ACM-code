#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<string>
#include<vector>
#include<stack>
#include<set>
#include<map>
#include<queue>
#include<algorithm>
#define ll long long
using namespace std;
const int maxn=1000005;
int a[maxn];
const int mod=10007;
void init(){
	a[0]=0;
	a[1]=1;
	for(int i=2;i<=maxn;i++){
		a[i]=(a[i-2]%mod+a[i-1]%mod)%mod;
	}
}
int main(){
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	init();
	int num;
	while(~scanf("%d",&num)){
		printf("%d\n",a[num]);
	}
    return 0;
}
