#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<string>
#include<vector>
#include<stack>
#include<set>
#include<map>
#include<queue>
#include<algorithm>
#define ll long long
using namespace std;
const int maxn=10000;
int main(){
	freopen("a.in","w",stdout);
	for(int k=1;k<=1000;k++){
		printf("%d\n",rand()%2001);
	}
    return 0;
}
