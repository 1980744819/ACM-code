#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<string>
#include<vector>
#include<stack>
#include<set>
#include<map>
#include<queue>
#include<algorithm>
#define ll long long
using namespace std;
const int maxn=1005;
int a[maxn],b[maxn];
void dfs(int num){
	int coun=0;
	stack<int>st;
	while(num!=0){
		if(num%2==1){
			st.push(coun);
		}
		coun++;
		num/=2;
	}
	while(!st.empty()){
		int tmp=st.top();
		printf("2");
		if(tmp!=1){
			printf("(");
			if(tmp!=0)
				dfs(tmp);
			else
				printf("0");
			printf(")");
		}
		st.pop();
		if(!st.empty()){
			printf("+");
		}
	}
}
int main(){
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	int num;
	while(~scanf("%d",&num)){
		dfs(num);
		printf("\n");
	}
    return 0;
}
