#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<string>
#include<vector>
#include<stack>
#include<set>
#include<map>
#include<queue>
#include<algorithm>
#define ll long long
using namespace std;
const int maxn=10000;
int a[100];
int length=0;
void trans(int num){
	length=0;
	while(num!=0){
		int tmp=num%10;
		a[length++]=tmp;
		num/=10;
	}
}
bool judge(int num){
	trans(num);
	int left=0,right=length-1;
	if(right<left)
		return false;
	while(right>=left){
		if(a[right]!=a[left])
			return false;
		right--;
		left++;
	}
	return true;
}

int add_sum(){
	int ans=0;
	for(int i=0;i<length;i++){
		ans+=a[i];
	}
	return ans;
}
int main(){
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	std::vector<int> v[60];
	for(int i=10000;i<=999999;i++){
		if(judge(i)){
			v[add_sum()].push_back(i);
		}
	}
	int num;
	while(~scanf("%d",&num)){
		for(int i=0;i<v[num].size();i++){
			printf("%d\n",v[num][i]);
		}
	}
    return 0;
}
